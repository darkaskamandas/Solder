﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    #region Singleon class: GameManager
    public static GameManager Instance;

    public void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    #endregion

    Camera cam;

    public Solder ball;
    public Tragector tragector;

    [SerializeField] float pushForce = 4f;

    bool isDragging = false;

    Vector2 startPoint;
    Vector2 endPoint;
    Vector2 direction;
    Vector2 forse;
    float distance;

    public void Start()
    {
        cam = Camera.main;
        ball.DesactivateRb();
    }

    public void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            isDragging = true;
            OnDragStart();
        }
        if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
            OnDragEnd();
        }
        if (isDragging)
        {
            OnDrag();
        }
    }
    public void OnDragStart()
    {
        ball.DesactivateRb();
        startPoint = cam.ScreenToWorldPoint(Input.mousePosition);

        tragector.Show();

    }
    public void OnDrag()
    {
        endPoint = cam.ScreenToWorldPoint(Input.mousePosition);
        distance = Vector2.Distance(startPoint, endPoint);
        direction = (startPoint - endPoint).normalized;
        forse = direction * distance * pushForce;

        Debug.DrawLine(startPoint, endPoint);

        tragector.UpdateDots(ball.pos, forse);
    }
    public void OnDragEnd()
    {
        ball.ActivateRb();
        ball.Push(forse);
        tragector.Hide();
    }
}
